
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe extends JFrame implements ActionListener {

    private JButton[][] buttons = new JButton[3][3];
    private char currentPlayer = 'X';
    private boolean gameOver = false;

    // Score variables
    private int scoreX = 0;
    private int scoreO = 0;
    private final JLabel scoreLabel = new JLabel("X: 0   O: 0");

    private final JLabel statusLabel = new JLabel("Player X's turn");

    public TicTacToe() {
        setTitle("Tic Tac Toe");
        setSize(420, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createHeaderPanel(), BorderLayout.NORTH);
        add(createBoardPanel(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);

        setVisible(true);
    }

    // --- HEADER ---
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(240, 240, 240));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Tic Tac Toe");
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(new Color(34, 34, 34));
        header.add(title, BorderLayout.WEST);

        // Score label
        scoreLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        scoreLabel.setForeground(new Color(90, 90, 90));
        header.add(scoreLabel, BorderLayout.EAST);

        // Status label
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        statusLabel.setForeground(new Color(100, 100, 100));
        header.add(statusLabel, BorderLayout.SOUTH);

        return header;
    }

    // --- BOARD ---
    private JPanel createBoardPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 3, 12, 12));
        panel.setBackground(new Color(246, 246, 248));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = createButton();
                panel.add(buttons[i][j]);
            }
        }
        return panel;
    }

    private JButton createButton() {
        JButton btn = new JButton("");
        btn.setFont(new Font("Segoe UI", Font.BOLD, 48));
        btn.setFocusPainted(false);
        btn.setBackground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220), 2));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (btn.getText().equals("")) btn.setBackground(new Color(230, 230, 230));
            }
            public void mouseExited(MouseEvent e) {
                if (btn.getText().equals("")) btn.setBackground(Color.WHITE);
            }
        });

        btn.addActionListener(this);
        return btn;
    }

    // --- BOTTOM PANEL (Reset Game) ---
    private JPanel createBottomPanel() {
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.setBackground(new Color(240, 240, 240));

        JButton resetButton = new JButton("Reset Game");
        resetButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        resetButton.setPreferredSize(new Dimension(120, 36));
        resetButton.addActionListener(e -> resetBoard());

        bottom.add(resetButton);
        return bottom;
    }

    // --- GAME LOGIC ---
    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameOver) return;

        JButton clicked = (JButton) e.getSource();
        if (!clicked.getText().equals("")) return;

        clicked.setText(String.valueOf(currentPlayer));
        clicked.setForeground(currentPlayer == 'X' ? new Color(50, 50, 50) : new Color(80, 80, 80));

        if (checkWin(currentPlayer)) {
            gameOver = true;
            if (currentPlayer == 'X') scoreX++;
            else scoreO++;
            updateScore();
            showResult("Player " + currentPlayer + " wins!");
            return;
        }

        if (isBoardFull()) {
            gameOver = true;
            showResult("It's a tie!");
            return;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        statusLabel.setText("Player " + currentPlayer + "'s turn");
    }

    private boolean checkWin(char p) {
        String s = String.valueOf(p);

        for (int i = 0; i < 3; i++)
            if (buttons[i][0].getText().equals(s) &&
                    buttons[i][1].getText().equals(s) &&
                    buttons[i][2].getText().equals(s))
                return true;

        for (int i = 0; i < 3; i++)
            if (buttons[0][i].getText().equals(s) &&
                    buttons[1][i].getText().equals(s) &&
                    buttons[2][i].getText().equals(s))
                return true;

        if (buttons[0][0].getText().equals(s) &&
                buttons[1][1].getText().equals(s) &&
                buttons[2][2].getText().equals(s))
            return true;

        if (buttons[0][2].getText().equals(s) &&
                buttons[1][1].getText().equals(s) &&
                buttons[2][0].getText().equals(s))
            return true;

        return false;
    }

    private boolean isBoardFull() {
        for (JButton[] row : buttons)
            for (JButton b : row)
                if (b.getText().equals("")) return false;
        return true;
    }

    private void showResult(String message) {
        int option = JOptionPane.showConfirmDialog(
                this,
                message + "\nPlay again?",
                "Game Over",
                JOptionPane.YES_NO_OPTION
        );

        if (option == JOptionPane.YES_OPTION) resetBoard();
        else System.exit(0);
    }

    private void resetBoard() {
        currentPlayer = 'X';
        gameOver = false;
        for (JButton[] row : buttons)
            for (JButton b : row) {
                b.setText("");
                b.setBackground(Color.WHITE);
            }
        statusLabel.setText("Player X's turn");
    }

    private void updateScore() {
        scoreLabel.setText("X: " + scoreX + "   O: " + scoreO);
    }
    // --- MAIN ---
    public static void main(String[] args) {
        new TicTacToe();
    }
}
